import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome!!");
		while(true) {
			System.out.println("Menu:");
			System.out.println("1. Length Conversion");
			System.out.println("2. Weight Conversion");
			System.out.println("3. Temperature Conversion");
			System.out.println("0. Exit");
			int choice=sc.nextInt();
			switch (choice) {
			case 1:
				Convertor.lengthCoversion();
				break;
			case 2:
				Convertor.weightCoversion();
				break;
			case 3:
				Convertor.tempCoversion();
				break;
			case 0:
				System.out.println("Powring Off...");
				sc.close();
				return;
			default:
				System.out.println("Wrong Selection! Try Again");
			}
		}
	}
}
