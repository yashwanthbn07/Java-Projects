import java.util.Scanner;

public class Convertor {
	static Scanner sc=new Scanner(System.in);
	public static void lengthCoversion() {
		while(true) {
			System.out.println("Choose coversion type");
			System.out.println("1. Meters to Feets");
			System.out.println("2. Feets to Meters");
			System.out.println("0. Back");
			int type=sc.nextInt();
			switch (type) {
			case 1:
				System.out.println("Enter length in Meters");
				double input=sc.nextDouble();
				metersToFeets(input);
				break;
			case 2:
				System.out.println("Enter length in feets");
				double input1=sc.nextDouble();
				feetsToMeters(input1);
				break;
			case 0:
				System.out.println("Returning to Main Menu");
				return;
			default:
				System.out.println("Wrong Selection Buddy");
			}
		}
	}
	public static void weightCoversion() {
		while(true) {
			System.out.println("Choose coversion type");
			System.out.println("1. Kilograms to Pounds");
			System.out.println("2. Pounds to Kilograms");
			System.out.println("0. Back");
			int type=sc.nextInt();
			switch (type) {
			case 1:
				System.out.println("Enter weight in Kilograms");
				double input=sc.nextDouble();
				kgsToPounds(input);
				break;
			case 2:
				System.out.println("Enter weight in Pounds");
				double input1=sc.nextDouble();
				poundsToKgs(input1);
				break;
			case 0:
				System.out.println("Returning to Main Menu");
				return;
			default:
				System.out.println("Wrong Selection Buddy");
			}
		}
	}
	public static void tempCoversion() {
		while(true) {
			System.out.println("Choose coversion type");
			System.out.println("1. Celsius to Fahrenheit");
			System.out.println("2. Fahrenheit to Celsius");
			System.out.println("0. Back");
			int type=sc.nextInt();
			switch (type) {
			case 1:
				System.out.println("Enter temperature in Celsius");
				double input=sc.nextDouble();
				cToF(input);
				break;
			case 2:
				System.out.println("Enter temperature in Fahrenheit");
				double input1=sc.nextDouble();
				fToC(input1);
				break;
			case 0:
				System.out.println("Returning to Main Menu");
				return;
			default:
				System.out.println("Wrong Selection Buddy");
			}
		}
	}
	private static void metersToFeets(double input) {
		System.out.printf("%.2f Meters = %.2f feets%n",input,(input*3.28084));
	}
	private static void feetsToMeters(double input) {
		System.out.printf("%.2f feets = %.2f Meters%n",input,(input/3.28084));
	}
	private static void kgsToPounds(double input) {
		System.out.printf("%.2f Kilograms = %.2f Pounds%n",input,(input*2.20462));
	}
	private static void poundsToKgs(double input) {
		System.out.printf("%.2f Pounds = %.2f Kilograms%n",input,(input/2.20462));
	}
	private static void cToF(double c) {
		System.out.println(c+"C = "+((c * 9/5) + 32)+"F");
	}
	private static void fToC(double f) {
		System.out.println(f+"F = "+((f - 32) * 5/9)+"C");
	}
}
