package com.Bank;

public class Account {
    static int number = 1;
    int accountNumber;
    String accountHolderName;
    double balance;

    public Account(String accountHolderName, double balance) {
        this.accountNumber = number++;
        this.accountHolderName = accountHolderName;
        this.balance = balance;
        System.out.println("Account created successfully!");
        System.out.println("Your account number is: " + this.accountNumber);
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited successfully. Current balance: " + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Invalid withdrawal amount.");
        } else if (amount > balance) {
            System.out.println("Insufficient balance.");
        } else {
            balance -= amount;
            System.out.println("Withdrawn successfully. Remaining balance: " + balance);
        }
    }

    public void getBalance() {
        System.out.println("Current balance: " + balance);
    }
}

