package com.Bank;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ArrayList<Account> accounts = new ArrayList<>();
        System.out.println("Welcome to the Bank!");
        while (true) {
            System.out.println("Menu:");
            System.out.println("1. Create account");
            System.out.println("2. Deposit money");
            System.out.println("3. Withdraw money");
            System.out.println("4. Balance Inquiry");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.print("Enter account holder name: ");
                    sc.nextLine();
                    String name = sc.nextLine();
                    System.out.print("Enter initial deposit amount: ");
                    double deposit = sc.nextDouble();
                    accounts.add(new Account(name, deposit));
                    break;
                case 2:
                    System.out.print("Enter account number: ");
                    int accNo = sc.nextInt();
                    Account acc = findAccount(accounts, accNo);
                    if (acc != null) {
                        System.out.print("Enter deposit amount: ");
                        double depAmount = sc.nextDouble();
                        acc.deposit(depAmount);
                    } else {
                        System.out.println("Account not found.");
                    }
                    break;
                case 3:
                    System.out.print("Enter account number: ");
                    int accNoWithdraw = sc.nextInt();
                    Account accWithdraw = findAccount(accounts, accNoWithdraw);
                    if (accWithdraw != null) {
                        System.out.print("Enter withdrawal amount: ");
                        double withdrawAmount = sc.nextDouble();
                        accWithdraw.withdraw(withdrawAmount);
                    } else {
                        System.out.println("Account not found.");
                    }
                    break;
                case 4:
                    System.out.print("Enter account number: ");
                    int accNoBalance = sc.nextInt();
                    Account accBalance = findAccount(accounts, accNoBalance);
                    if (accBalance != null) {
                        accBalance.getBalance();
                    } else {
                        System.out.println("Account not found.");
                    }
                    break;
                case 0:
                    System.out.println("Thank you for using our banking system!");
                    sc.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    private static Account findAccount(ArrayList<Account> accounts, int accountNumber) {
        for (Account acc : accounts) {
            if (acc.accountNumber == accountNumber) {
                return acc;
            }
        }
        return null;
    }
}
