package com.TODO;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class TODO {
	public static void add(ArrayList<String> list,String task) {
		list.add(task);
		save(list);
		System.out.println("Task added successfully!!");
	}
	public static void remove(ArrayList<String> list,int index) {
		list.remove(index-1);
		System.out.println("Task removed successfully");
	}
	public static void update(ArrayList<String> list,int index,String s) {
		list.set(index-1, s);
		saveWrite(list);
		System.out.println("Task updated successfully");
	}
	public static void view(ArrayList<String> list) {
		System.out.println("Tasks are:");
		for(int i=0;i<list.size();i++) {
			System.out.println((i+1) +". "+list.get(i));
		}
	}
    public static int getValidNumber(Scanner sc) {
        while (true) {
            if (sc.hasNextInt()) {
                return sc.nextInt();
            } else {
                System.out.println("Invalid input! Please enter a valid number:");
                sc.next();
            }
        }
    }
	// method to fetch task from texts.txt file and store them in ArrayList
	public static ArrayList<String> fetch() {
		ArrayList<String> list=new ArrayList<String>();
		String path = "C:\\IO\\tasks.txt";
		File file=new File(path);
		if(!file.exists()) {
			try {
				file.createNewFile();
				System.out.println("Tasks file created at "+file.getAbsolutePath());
			} catch (Exception e) {
				System.out.println("Error in creating tasks file");
			}
		}
		try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
			String line;
			while((line=reader.readLine()) != null) {
				list.add(line);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	public static void save(ArrayList<String> list) {
		String path = "C:\\IO\\tasks.txt";
		File file=new File(path);
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
			for(String s : list) {
				writer.write(s);
				writer.newLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void saveWrite(ArrayList<String> list) {
		String path = "C:\\IO\\tasks.txt";
		File file=new File(path);
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
			for(String s : list) {
				writer.write(s);
				writer.newLine();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
