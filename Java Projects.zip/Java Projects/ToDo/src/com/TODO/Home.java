package com.TODO;
import java.util.ArrayList;
import java.util.Scanner;
public class Home {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Welcome!!");
		ArrayList<String> list = TODO.fetch();
		while (true) {
			System.out.println("\nMenu:");
			System.out.println("1. Show Existing Tasks");
			System.out.println("2. Add a Task");
			System.out.println("3. Remove a Task");
			System.out.println("4. Update a Task");
			System.out.println("0. Exit");
			System.out.println("Enter your choice:");
			int choice = TODO.getValidNumber(sc);
			sc.nextLine();
			switch (choice) {
			case 1: {
				TODO.view(list);
				break;
			}
			case 2: {
				System.out.println("Enter the task");
				String task = sc.nextLine();
				TODO.add(list, task);
				break;
			}
			case 3: {
				TODO.view(list);
				System.out.println("Enter the index number of the task to remove");
				int index = sc.nextInt();
				TODO.remove(list, index);
				break;
			}case 4: {
				TODO.view(list);
				System.out.println("Enter the index number of the task to update");
				int index = sc.nextInt();
				sc.nextLine();
				System.out.println("Enter the task description");
				String s=sc.nextLine();
				TODO.update(list, index,s);
				break;
			}
			case 0: {
				System.out.println("Now powering off....");
				sc.close();
				return;
			}
			default:
				System.out.println("Invalid selection. Please try again.");
			}
		}
	}
}

