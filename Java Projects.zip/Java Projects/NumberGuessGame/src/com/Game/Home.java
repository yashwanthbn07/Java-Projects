package com.Game;
import java.util.*;
public class Home {

	public static void main(String[] args) {
		try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Welcome!!");
			System.out.println("Enter maximum range");
			int range=sc.nextInt();
			int num=new Random().nextInt(range);
			System.out.println("Guess the number between 0 to "+range);
			int count=0;
			Thread.currentThread();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			while(true) {
				System.out.println("Enter your number");
				int n=sc.nextInt();
				Game.guess(num, n, range);
				System.out.println("Number of Attempts - "+(++count));
				if(n==num) {
					System.err.println("JackPot!!");
					switch (count) {
					case 1,2,3,4,5: {
						System.err.println("God Level");
						break;
					}
					case 6,7,8,9,10: {
						System.err.println("IQ 200");
						break;
					}
					case 11,12,13,14,15: {
						System.err.println("Human");
						break;
					}
					default:
						System.err.println("Waste! Commit suicide");
					}
					return;
				}
			}
		}
	}
}
