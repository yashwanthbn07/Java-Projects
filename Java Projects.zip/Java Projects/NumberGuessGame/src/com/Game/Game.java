package com.Game;

public class Game {
	public static void guess(int num,int n,int range) {
		if(n<num) {
			System.out.println("Too low");
		}
		if(n>num) {
			System.out.println("Too high");
		}
		if(n<0 || n>range) {
			System.out.print(" & Out of Range");
		}
	}
}
