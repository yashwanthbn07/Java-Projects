package com.Calculator;
import java.util.Scanner;
public class Home {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Welcome!!");
		while(true) {
			System.out.println("Here is the menu");
			System.out.println("Press A for Adiition");
			System.out.println("Press S for Subtraction");
			System.out.println("Press M for Multiplication");
			System.out.println("Press D for Division");
			System.out.println("Press m for Modulus");
			System.out.println("Press P for Power");
			System.out.println("Press s for Squreroot");
			System.out.println("Press 0 to exit");
			char ch=sc.next().charAt(0);
			switch (ch) {
			case 'A': {
				System.out.println("Enter two numbers");
				double num1=Calci.getValidNumber(sc);
				double num2=Calci.getValidNumber(sc);
				Calci.add(num1,num2);
				break;
			}
			case 'S': {
				System.out.println("Enter two numbers");
				double num1=Calci.getValidNumber(sc);
				double num2=Calci.getValidNumber(sc);
				Calci.sub(num1,num2);
				break;
			}
			case 'M': {
				System.out.println("Enter two numbers");
				double num1=Calci.getValidNumber(sc);
				double num2=Calci.getValidNumber(sc);
				Calci.mul(num1,num2);
				break;
			}
			case 'D': {
				System.out.println("Enter two numbers");
				double num1=Calci.getValidNumber(sc);
				double num2=Calci.getValidNumber(sc);
				Calci.div(num1,num2);
				break;
			}
			case 'm': {
				System.out.println("Enter two numbers");
				double num1=Calci.getValidNumber(sc);
				double num2=Calci.getValidNumber(sc);
				Calci.mod(num1,num2);
				break;
			}
			case 'P': {
				System.out.println("Enter base and power");
				double base=Calci.getValidNumber(sc);
				double p=Calci.getValidNumber(sc);
				Calci.power(base,p);
				break;
			}
			case 's': {
				System.out.println("Enter the number");
				double num=Calci.getValidNumber(sc);
				Calci.squareroot(num);
				break;
			}
			case '0':
				System.out.println("Shutting Down...");
				sc.close();
				return;
			default:
				System.out.println("Oh Oh Not Good... Wrong key...\nPlease try again...");
			}
		}
	}
}
