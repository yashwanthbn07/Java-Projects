package com.Calculator;
import java.util.Scanner;
public class Calci {
	public static void add(double a,double b) {
		displayFormat((a+b));
	}
	public static void sub(double a,double b) {
		displayFormat((a-b));
	}
	public static void mul(double a,double b) {
		displayFormat((a*b));
	}
	public static void div(double a,double b) {
		if(b==0) {
			System.out.println("Sorry!! Cannot divide by zero..");
			return;
		}
		displayFormat((a/b));
	}
	public static void mod(double a,double b) {
		displayFormat((a%b));
	}
	public static void power(double b,double p) {
		displayFormat(Math.pow(b, p));
	}
	public static void squareroot(double num) {
		displayFormat(Math.sqrt(num));
	}
    public static double getValidNumber(Scanner sc) {
        while (true) {
            if (sc.hasNextDouble()) {
                return sc.nextDouble();
            } else {
                System.out.println("Invalid input! Please enter a valid number:");
                sc.next();
            }
        }
    }
    public static void displayFormat(double res) {
    	if(res==(int)res) {
    		System.out.println("= "+(int)res);
    	}else {
    		System.out.println("= "+res);
    	}
	}
}
